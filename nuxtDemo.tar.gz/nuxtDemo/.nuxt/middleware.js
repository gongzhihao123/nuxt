const middleware = {}

middleware['nuxtAuth'] = require('../middleware/nuxtAuth.js');
middleware['nuxtAuth'] = middleware['nuxtAuth'].default || middleware['nuxtAuth']

middleware['reportAuth'] = require('../middleware/reportAuth.js');
middleware['reportAuth'] = middleware['reportAuth'].default || middleware['reportAuth']

export default middleware
