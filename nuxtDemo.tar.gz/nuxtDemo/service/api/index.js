import charts from './charts'
import user from './user'
import project from './project'
import alarm from './alarm'
import bread from './bread'
import nuxt from './nuxt'
export default {
  charts,
  user,
  project,
  alarm,
  bread,
  nuxt
}
