// 页面初始化完成之后的公共静态数据
export default {
  // 根据配置文件过滤的cookie信息
  cookies: {},
  //  url请求参数
  query: {},
  // 用户信息
  userInfo: {},
  // 下拉框数据
  selectOptions: {}
}
