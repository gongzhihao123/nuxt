<template>
  <div>
    111111111
  </div>
</template>

<script>
import InitPage from '~/components/InitPageReport'
export default {
  name: 'AlarmManage',
  head: {
    title: '告警管理'
  },
  mixins: [InitPage]
}
</script>

<style scoped>

</style>
