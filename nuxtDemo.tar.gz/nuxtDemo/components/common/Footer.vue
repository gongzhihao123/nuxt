<template>
  <footer>
    <div class="page-footer">
      北京云测信息技术有限公司 &copy; 2011-2019京ICP备11040545号
    </div>
  </footer>
</template>
<style lang="less">
  .page-footer {
    padding: 10px 20px 11px;
    border-top: 1px solid #e1e9f0;
    background-color: #f0f4fa;
    color: #999999;
    text-align: center;
  }
</style>
