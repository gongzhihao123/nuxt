import global from '../global'
export default Object.assign({}, global, {
  CM_API: {
    hostname: 'https://www.easy-mock.com/mock/5c00e41357282f4cecbc664a/monitor'
  }
})
